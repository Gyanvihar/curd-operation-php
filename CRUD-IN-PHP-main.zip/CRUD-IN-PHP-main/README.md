# CRUD-IN-PHP
Create . Read . Update . Delete
